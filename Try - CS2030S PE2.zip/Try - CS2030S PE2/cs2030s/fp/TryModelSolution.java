package cs2030s.fp;

public abstract class TryModelSolution<T> {
  public static <T> TryModelSolution<T> failure(Throwable a) {
    return new Failure<T>(a);
  }

  public static <T> TryModelSolution<T> success(T value) {
    return new Success<T>(value);
  }

  public static <T> TryModelSolution<T> of(Producer<? extends T> producer) {
    try {
      return success(producer.produce());
    } catch (Throwable e) {
      return failure(e);
    }
  }

  public abstract T get() throws Throwable;
  public abstract <R> TryModelSolution<R> map(Transformer<? super T, ? extends R> mapper);
  public abstract <R> TryModelSolution<R> flatMap(Transformer<? super T, ? extends TryModelSolution<? extends R>> mapper);
  public abstract TryModelSolution<T> onFailure(Consumer<? super Throwable> consumer);
  public abstract TryModelSolution<T> recover(Transformer<? super Throwable, ? extends T> transformer);

  private static class Success<T> extends TryModelSolution<T> {
    T value;

    Success(T value) {
      this.value = value;
    }

    public <R> TryModelSolution<R> map(Transformer<? super T, ? extends R> mapper) {
      try {
        return success(mapper.transform(value));
      } catch (Throwable e) {
        return failure(e);
      }
    }

    public <R> TryModelSolution<R> flatMap(Transformer<? super T, ? extends TryModelSolution<? extends R>> mapper) {
      @SuppressWarnings("unchecked")
      TryModelSolution<R> t =  (TryModelSolution<R>) mapper.transform(value);
      return t;
    }

    public T get() throws Throwable {
      return value;
    }

    public TryModelSolution<T> onFailure(Consumer<? super Throwable> consumer) {
      return this;
    }

    public TryModelSolution<T> recover(Transformer<? super Throwable, ? extends T> transformer) {
      return this;
    }
  }

  private static class Failure<T> extends TryModelSolution<T> {
    Throwable throwable;

    Failure(Throwable value) {
      this.throwable = value;
    }

    public <R> Failure<R> map(Transformer<? super T, ? extends R> mapper) {
      @SuppressWarnings("unchecked")
      Failure<R> t =  (Failure<R>) this;
      return t;
    }

    public <R> Failure<R> flatMap(Transformer<? super T, ? extends TryModelSolution<? extends R>> mapper) {
      @SuppressWarnings("unchecked")
      Failure<R> t =  (Failure<R>) this;
      return t;
    }

    public T get() throws Throwable {
      throw throwable;
    }

    public TryModelSolution<T> onFailure(Consumer<? super Throwable> consumer) {
      try {
        consumer.consume(this.throwable);
        return this;
      } catch (Throwable t) {
        return failure(t);
      }
    }

    public TryModelSolution<T> recover(Transformer<? super Throwable, ? extends T> transformer) {
      try {
        return success(transformer.transform(this.throwable));
      } catch (Throwable t) {
        return failure(t);
      }
    }
  }
}
