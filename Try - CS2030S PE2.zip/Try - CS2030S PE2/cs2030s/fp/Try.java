package cs2030s.fp;

/**
 * Encapsulates a value or an error.
 * CS2030S PE2 Question 1
 * AY20/21 Semester 2
 *
 * @author A0244104W
 */
public abstract class Try<T> {

  private static class Success<T> extends Try<T> {
    private final  T value;

    private Success(T value) {
      this.value = value;
    }

    @Override
    public T get() {
      return this.value;
    }

    @Override
    public <U> Try<U> map(Transformer<? super T, ? extends U> transformer) {
      try {
        return Try.success(transformer.transform(this.value));
      } catch (Throwable e) {
        return Try.failure(e);
      }
    }
    
    @Override
    public <U> Try<U> flatMap(Transformer<? super T, ? extends Try<? extends U>> transformer) {
      try {
        return Try.success(transformer.transform(this.value).get());
      } catch (Throwable e) {
        return Try.failure(e);
      }
    }
    
    @Override
    public Try<T> onFailure(Consumer<? super T> consumer) {
      return this;
    }
    
    @Override
    public <T> Try<T> recover(Transformer<? super T, T> transformer) {
      //@SuppressWarnings("unchecked")
      //U mapped = (U) this.value;
      return this;
    }
    
    @Override
    public boolean equals(Object o) {
      if (o == null) {
        return false;
      } else if (o == this) {
        return true;
      }

      if (o instanceof Success<?>) {
        Success<?> object = (Success<?>) o;
        if (this.get() == object.get()) {
          return true;
        }
        
        if (this.value == null || object.value == null) {
          return false; 
        }
        return this.get().equals(object.get());
      }
      return false; 
    }
  }
  
  private static class Failure extends Try<Throwable> {
    private final Throwable error;
    private final String errorString;

    private Failure(Throwable error) {
      this.error = error;
      this.errorString = error.toString();
    } 
    
    @Override
    public <U> Try<U> map(Transformer<? super Throwable, ? extends U> transformer) {
      return Try.failure(this.error);
    }
    
    @Override 
    public Throwable get() throws Throwable {
      throw this.error;
    }

    @Override
    public <U> Try<U> flatMap(Transformer<? super Throwable, 
        ? extends Try<? extends U>> transformer) {
      return Try.failure(this.error);
    }
    
    @Override
    public Try<Throwable> onFailure(Consumer<? super Throwable> consumer) {
      try {
        consumer.consume(this.error);
        return this;
      } catch (Throwable e) {
        return Try.failure(e);
      }
    }

    @Override
    public <U> Try<U> recover(Transformer<? super Throwable, ? extends U> transformer) {
      try {
        return Try.of(() -> transformer.transform(this.error));
      } catch (Throwable e) {
        return Try.failure(e);
      }
    }
    
    @Override
    public boolean equals(Object o) {
      if (o == null) {
        return false;
      } else if (o == this) {
        return true;
      }

      if (o instanceof Failure) {
        Failure failedObject = (Failure) o;

        if (this.errorString == failedObject.errorString) {
          return true;
        }

        if (this.error == null || failedObject.error == null) {
          return false; 
        }

        return this.errorString.equals(failedObject.errorString);
      }
      return false; 
    }

  }  
  
 
  public static <T> Try<T> of(Producer<? extends T> producer) {
    try {
      return success(producer.produce());
    } catch (Throwable e) {
      return failure(e);
    }
  }

  public static <T> Try<T> failure(Throwable e) {
    @SuppressWarnings("unchecked")
    Try<T> failure = (Try<T>) new Failure(e);
    return failure;
  }
  
  public static <T> Try<T> success(T value) {
    return new Success<T>(value);
  }

  public abstract Try<T> onFailure(Consumer<? super T> consumer);

  public abstract <U> Try<U> recover(Transformer<? super T, ? extends U> transformer);

  public abstract <U> Try<U> map(Transformer<? super T, ? extends U> transformer);
  
  public abstract <U> Try<U> flatMap(Transformer<? super T, 
      ? extends Try<? extends U>> transformer);
  
  public abstract T get() throws Throwable;
}
